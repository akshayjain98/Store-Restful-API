from db import db
from Model.UserProjectModel import user_project


class UserModel(db.Model):
    __tablename__ = "user"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(30))
    project = db.relationship("user", secondary=user_project)

    def __init__(self, _id, name):
        self.id = _id
        self.name = name

    def save_user(self):
        # Add new project
        db.session.add(self)
        db.session.commit()

    def get_by_name(self, name):
        return self.query.filter_by(name=name)