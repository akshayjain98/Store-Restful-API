from db import db
from Model.UserProjectModel import user_project


class ProjectModel(db.Model):
    # table name
    __tablename__ = "project"

    # table Columns
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80))
    user = db.relationship('user', secondary=user_project)

    def __init__(self, _id, name):
        self.id = _id
        self.name = name

    def save_project(self):
        # Add new project
        db.session.add(self)
        db.session.commit()

    def get_project(self):
        pass