from flask import Flask
app = Flask(__name__)
from Model.UserModel import UserModel
from Model.ProjectModel import ProjectModel

app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///project.db"


# Creating all the tables
@app.before_first_request
def create_tables():
    db.create_all()


if __name__ == "__main__":
    from db import db

    db.init_app(app)
    # Server running at default port 5000
    app.run(debug=True)
